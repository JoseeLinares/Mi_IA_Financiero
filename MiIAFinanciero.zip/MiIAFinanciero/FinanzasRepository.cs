using System;
using System.Data;
using System.Data.SqlClient;

namespace MiIAFinanciero
{
    public class FinanzasRepository
    {
        // Usa la instancia correcta de SQL Server
        private readonly string connectionString = "Server=DESKTOP-K63CMO6\\SQLEXPRESS;Database=Mi IA Financiero;Trusted_Connection=True;";

        public void InsertarIngresoEgreso(DateTime fecha, decimal monto, string tipo, string descripcion)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText =
                    @"INSERT INTO IngresosEgresos (Fecha, Monto, Tipo, Descripcion)
                      VALUES (@fecha, @monto, @tipo, @descripcion)";
                command.Parameters.AddWithValue("@fecha", fecha);
                command.Parameters.AddWithValue("@monto", monto);
                command.Parameters.AddWithValue("@tipo", tipo);
                command.Parameters.AddWithValue("@descripcion", descripcion);
                command.ExecuteNonQuery();
            }
        }

        public DataTable ObtenerIngresosEgresos()
        {
            var dt = new DataTable();
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = new SqlCommand("SELECT * FROM IngresosEgresos ORDER BY Fecha DESC", connection);
                using (var adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(dt);
                }
            }
            return dt;
        }

        public void EliminarIngresoEgreso(int id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "DELETE FROM IngresosEgresos WHERE Id = @id";
                command.Parameters.AddWithValue("@id", id);
                command.ExecuteNonQuery();
            }
        }

        public void ActualizarIngresoEgreso(int id, DateTime fecha, decimal monto, string tipo, string descripcion)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText =
                    @"UPDATE IngresosEgresos
                      SET Fecha = @fecha, Monto = @monto, Tipo = @tipo, Descripcion = @descripcion
                      WHERE Id = @id";
                command.Parameters.AddWithValue("@fecha", fecha);
                command.Parameters.AddWithValue("@monto", monto);
                command.Parameters.AddWithValue("@tipo", tipo);
                command.Parameters.AddWithValue("@descripcion", descripcion);
                command.Parameters.AddWithValue("@id", id);
                command.ExecuteNonQuery();
            }
        }

        public void InsertarFactura(DateTime fecha, string rutaImagen, decimal total, string proveedor, string detalles)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText =
                    @"INSERT INTO Facturas (Fecha, RutaImagen, Total, Proveedor, Detalles)
                      VALUES (@fecha, @rutaImagen, @total, @proveedor, @detalles)";
                command.Parameters.AddWithValue("@fecha", fecha);
                command.Parameters.AddWithValue("@rutaImagen", rutaImagen);
                command.Parameters.AddWithValue("@total", total);
                command.Parameters.AddWithValue("@proveedor", proveedor);
                command.Parameters.AddWithValue("@detalles", detalles);
                command.ExecuteNonQuery();
            }
        }
    }
}