using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace MiIAFinanciero
{
    public partial class Form1 : Form
    {
        private readonly string connectionString = "Server=DESKTOP-K63CMO6\\SQLEXPRESS;Database=Mi IA Financiero;Trusted_Connection=True;";

        // Tus claves reales
        private readonly string azureApiKey = "API";
        private readonly string azureEndpoint = "https://miiafianciero.cognitiveservices.azure.com/"; // Tu endpoint real
        private readonly string openAIApiKey = "API";

        public Form1()
        {
            InitializeComponent();
            CargarDatos();
        }

        // INGRESOS/EGRESOS
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (decimal.TryParse(txtMonto.Text, out decimal monto) && !string.IsNullOrWhiteSpace(cmbTipo.Text))
            {
                InsertarIngresoEgreso(
                    dtpFecha.Value,
                    monto,
                    cmbTipo.Text,
                    txtDescripcion.Text
                );
                CargarDatos();
                LimpiarCampos();
            }
            else
            {
                MessageBox.Show("Verifica los datos ingresados.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void InsertarIngresoEgreso(DateTime fecha, decimal monto, string tipo, string descripcion)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText =
                    @"INSERT INTO IngresosEgresos (Fecha, Monto, Tipo, Descripcion)
                      VALUES (@fecha, @monto, @tipo, @descripcion)";
                command.Parameters.AddWithValue("@fecha", fecha);
                command.Parameters.AddWithValue("@monto", monto);
                command.Parameters.AddWithValue("@tipo", tipo);
                command.Parameters.AddWithValue("@descripcion", descripcion);
                command.ExecuteNonQuery();
            }
        }

        private void CargarDatos()
        {
            dgvDatos.DataSource = ObtenerIngresosEgresos();
        }

        private DataTable ObtenerIngresosEgresos()
        {
            var dt = new DataTable();
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = new SqlCommand("SELECT * FROM IngresosEgresos ORDER BY Fecha DESC", connection);
                using (var adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(dt);
                }
            }
            return dt;
        }

        private void LimpiarCampos()
        {
            txtMonto.Text = "";
            cmbTipo.SelectedIndex = -1;
            txtDescripcion.Text = "";
            dtpFecha.Value = DateTime.Now;
        }

        // FACTURAS: Subir y leer imagen
        private async void btnSubirFactura_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Im�genes (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp";
                ofd.Title = "Selecciona la foto de la factura";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    using (SaveFileDialog sfd = new SaveFileDialog())
                    {
                        sfd.Filter = "Im�genes (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp";
                        sfd.Title = "Guardar factura en...";
                        sfd.FileName = System.IO.Path.GetFileName(ofd.FileName);

                        if (sfd.ShowDialog() == DialogResult.OK)
                        {
                            System.IO.File.Copy(ofd.FileName, sfd.FileName, true);
                            txtRutaFactura.Text = sfd.FileName;

                            // Leer texto de la factura con Azure Computer Vision
                            string resultadoOCR = await LeerTextoFacturaAsync(sfd.FileName);
                            string textoPlano = ExtraerTextoPlanoDeOCR(resultadoOCR);
                            MessageBox.Show("Texto extra�do de la factura:\n\n" + textoPlano, "Factura Le�da", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Pide al usuario el total y proveedor (puedes mejorar esto con controles en la UI)
                            decimal total = 0;
                            string proveedor = "Desconocido";
                            if (decimal.TryParse(Microsoft.VisualBasic.Interaction.InputBox("Total de la factura:", "Total"), out decimal t))
                                total = t;
                            proveedor = Microsoft.VisualBasic.Interaction.InputBox("Proveedor de la factura:", "Proveedor");

                            // Guarda la factura en SQL
                            new FinanzasRepository().InsertarFactura(DateTime.Now, sfd.FileName, total, proveedor, textoPlano);

                            // Registra el egreso en IngresosEgresos
                            if (total > 0)
                            {
                                InsertarIngresoEgreso(DateTime.Now, total, "Egreso", $"Factura: {proveedor}");
                                CargarDatos();
                            }
                        }
                    }
                }
            }
        }

        // AZURE COMPUTER VISION OCR
        private async Task<string> LeerTextoFacturaAsync(string imagePath)
        {
            string url = azureEndpoint.TrimEnd('/') + "/vision/v3.2/ocr?language=es";
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", azureApiKey);
                byte[] imageBytes = System.IO.File.ReadAllBytes(imagePath);
                using (var content = new ByteArrayContent(imageBytes))
                {
                    content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                    var response = await client.PostAsync(url, content);
                    string result = await response.Content.ReadAsStringAsync();
                    return result; // Devuelve el JSON
                }
            }
        }

        // Procesa el JSON de Azure OCR y devuelve solo el texto plano
        private string ExtraerTextoPlanoDeOCR(string json)
        {
            try
            {
                using (JsonDocument doc = JsonDocument.Parse(json))
                {
                    StringBuilder sb = new StringBuilder();
                    var root = doc.RootElement;
                    if (root.TryGetProperty("regions", out JsonElement regions))
                    {
                        foreach (var region in regions.EnumerateArray())
                        {
                            if (region.TryGetProperty("lines", out JsonElement lines))
                            {
                                foreach (var line in lines.EnumerateArray())
                                {
                                    if (line.TryGetProperty("words", out JsonElement words))
                                    {
                                        foreach (var word in words.EnumerateArray())
                                        {
                                            if (word.TryGetProperty("text", out JsonElement text))
                                            {
                                                sb.Append(text.GetString() + " ");
                                            }
                                        }
                                    }
                                    sb.AppendLine();
                                }
                            }
                        }
                    }
                    return sb.ToString();
                }
            }
            catch
            {
                return "No se pudo procesar el texto de la factura.";
            }
        }

        // CONSEJOS IA: OpenAI GPT
        private async void btnObtenerConsejo_Click(object sender, EventArgs e)
        {
            string historial = ObtenerHistorialGastosComoTexto();
            string consejo = await ObtenerConsejoIAAsync(historial);
            txtConsejoIA.Text = consejo;
        }

        private string ObtenerHistorialGastosComoTexto()
        {
            var dt = ObtenerIngresosEgresos();
            StringBuilder texto = new StringBuilder();
            foreach (DataRow row in dt.Rows)
            {
                texto.AppendLine($"{row["Fecha"]}: {row["Tipo"]} {row["Monto"]} - {row["Descripcion"]}");
            }
            return texto.ToString();
        }

        private async Task<string> ObtenerConsejoIAAsync(string historialGastos)
        {
            string endpoint = "https://api.openai.com/v1/chat/completions";
            var requestBody = new
            {
                model = "gpt-3.5-turbo",
                messages = new[]
                {
                    new { role = "system", content = "Eres un asesor financiero personal." },
                    new { role = "user", content = $"Mi historial de gastos es: {historialGastos}. �Qu� consejo me das?" }
                }
            };

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {openAIApiKey}");
                var content = new StringContent(System.Text.Json.JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");
                var response = await client.PostAsync(endpoint, content);
                string result = await response.Content.ReadAsStringAsync();

                // Extraer solo el texto del consejo usando System.Text.Json
                try
                {
                    using (JsonDocument doc = JsonDocument.Parse(result))
                    {
                        var choices = doc.RootElement.GetProperty("choices");
                        if (choices.GetArrayLength() > 0)
                        {
                            var message = choices[0].GetProperty("message");
                            var adviceContent = message.GetProperty("content").GetString();
                            return adviceContent?.Replace("\\n", "\n") ?? "No se recibi� consejo.";
                        }
                    }
                }
                catch
                {
                    // Si falla el parseo, devuelve el JSON completo
                }
                return result;
            }
        }
    }
}