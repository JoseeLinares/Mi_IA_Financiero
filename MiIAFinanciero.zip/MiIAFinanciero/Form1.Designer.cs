﻿namespace MiIAFinanciero
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabIngresosEgresos;
        private System.Windows.Forms.TabPage tabFacturas;
        private System.Windows.Forms.TabPage tabReportes;
        private System.Windows.Forms.TabPage tabConsejosIA;

        // Controles para Ingresos/Egresos
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.Label lblMonto;
        private System.Windows.Forms.TextBox txtMonto;
        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.ComboBox cmbTipo;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.DataGridView dgvDatos;

        // Controles para Facturas
        private System.Windows.Forms.Button btnSubirFactura;
        private System.Windows.Forms.TextBox txtRutaFactura;

        // Controles para Consejos IA
        private System.Windows.Forms.Button btnObtenerConsejo;
        private System.Windows.Forms.TextBox txtConsejoIA;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabIngresosEgresos = new System.Windows.Forms.TabPage();
            this.tabFacturas = new System.Windows.Forms.TabPage();
            this.tabReportes = new System.Windows.Forms.TabPage();
            this.tabConsejosIA = new System.Windows.Forms.TabPage();

            this.lblFecha = new System.Windows.Forms.Label();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.lblMonto = new System.Windows.Forms.Label();
            this.txtMonto = new System.Windows.Forms.TextBox();
            this.lblTipo = new System.Windows.Forms.Label();
            this.cmbTipo = new System.Windows.Forms.ComboBox();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.txtDescripcion = new System.Windows.Forms.TextBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.dgvDatos = new System.Windows.Forms.DataGridView();

            this.btnSubirFactura = new System.Windows.Forms.Button();
            this.txtRutaFactura = new System.Windows.Forms.TextBox();

            this.btnObtenerConsejo = new System.Windows.Forms.Button();
            this.txtConsejoIA = new System.Windows.Forms.TextBox();

            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos)).BeginInit();
            this.tabControl.SuspendLayout();
            this.tabIngresosEgresos.SuspendLayout();
            this.tabFacturas.SuspendLayout();
            this.tabConsejosIA.SuspendLayout();
            this.SuspendLayout();

            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabIngresosEgresos);
            this.tabControl.Controls.Add(this.tabFacturas);
            this.tabControl.Controls.Add(this.tabReportes);
            this.tabControl.Controls.Add(this.tabConsejosIA);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(800, 600);
            this.tabControl.TabIndex = 0;

            // 
            // tabIngresosEgresos
            // 
            this.tabIngresosEgresos.Controls.Add(this.lblFecha);
            this.tabIngresosEgresos.Controls.Add(this.dtpFecha);
            this.tabIngresosEgresos.Controls.Add(this.lblMonto);
            this.tabIngresosEgresos.Controls.Add(this.txtMonto);
            this.tabIngresosEgresos.Controls.Add(this.lblTipo);
            this.tabIngresosEgresos.Controls.Add(this.cmbTipo);
            this.tabIngresosEgresos.Controls.Add(this.lblDescripcion);
            this.tabIngresosEgresos.Controls.Add(this.txtDescripcion);
            this.tabIngresosEgresos.Controls.Add(this.btnAgregar);
            this.tabIngresosEgresos.Controls.Add(this.dgvDatos);
            this.tabIngresosEgresos.Location = new System.Drawing.Point(4, 24);
            this.tabIngresosEgresos.Name = "tabIngresosEgresos";
            this.tabIngresosEgresos.Padding = new System.Windows.Forms.Padding(3);
            this.tabIngresosEgresos.Size = new System.Drawing.Size(792, 572);
            this.tabIngresosEgresos.TabIndex = 0;
            this.tabIngresosEgresos.Text = "Ingresos/Egresos";
            this.tabIngresosEgresos.UseVisualStyleBackColor = true;

            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Location = new System.Drawing.Point(20, 20);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(43, 15);
            this.lblFecha.TabIndex = 0;
            this.lblFecha.Text = "Fecha:";

            // 
            // dtpFecha
            // 
            this.dtpFecha.Location = new System.Drawing.Point(80, 17);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(200, 23);
            this.dtpFecha.TabIndex = 1;

            // 
            // lblMonto
            // 
            this.lblMonto.AutoSize = true;
            this.lblMonto.Location = new System.Drawing.Point(20, 60);
            this.lblMonto.Name = "lblMonto";
            this.lblMonto.Size = new System.Drawing.Size(46, 15);
            this.lblMonto.TabIndex = 2;
            this.lblMonto.Text = "Monto:";

            // 
            // txtMonto
            // 
            this.txtMonto.Location = new System.Drawing.Point(80, 57);
            this.txtMonto.Name = "txtMonto";
            this.txtMonto.Size = new System.Drawing.Size(200, 23);
            this.txtMonto.TabIndex = 3;

            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Location = new System.Drawing.Point(20, 100);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(33, 15);
            this.lblTipo.TabIndex = 4;
            this.lblTipo.Text = "Tipo:";

            // 
            // cmbTipo
            // 
            this.cmbTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipo.Items.AddRange(new object[] {
            "Ingreso",
            "Egreso"});
            this.cmbTipo.Location = new System.Drawing.Point(80, 97);
            this.cmbTipo.Name = "cmbTipo";
            this.cmbTipo.Size = new System.Drawing.Size(200, 23);
            this.cmbTipo.TabIndex = 5;

            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.Location = new System.Drawing.Point(20, 140);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(73, 15);
            this.lblDescripcion.TabIndex = 6;
            this.lblDescripcion.Text = "Descripción:";

            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Location = new System.Drawing.Point(100, 137);
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(180, 23);
            this.txtDescripcion.TabIndex = 7;

            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(80, 180);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(200, 30);
            this.btnAgregar.TabIndex = 8;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);

            // 
            // dgvDatos
            // 
            this.dgvDatos.AllowUserToAddRows = false;
            this.dgvDatos.AllowUserToDeleteRows = false;
            this.dgvDatos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDatos.Location = new System.Drawing.Point(20, 230);
            this.dgvDatos.Name = "dgvDatos";
            this.dgvDatos.ReadOnly = true;
            this.dgvDatos.Size = new System.Drawing.Size(750, 300);
            this.dgvDatos.TabIndex = 9;

            // 
            // tabFacturas
            // 
            this.tabFacturas.Controls.Add(this.btnSubirFactura);
            this.tabFacturas.Controls.Add(this.txtRutaFactura);
            this.tabFacturas.Location = new System.Drawing.Point(4, 24);
            this.tabFacturas.Name = "tabFacturas";
            this.tabFacturas.Padding = new System.Windows.Forms.Padding(3);
            this.tabFacturas.Size = new System.Drawing.Size(792, 572);
            this.tabFacturas.TabIndex = 1;
            this.tabFacturas.Text = "Facturas";
            this.tabFacturas.UseVisualStyleBackColor = true;

            // 
            // btnSubirFactura
            // 
            this.btnSubirFactura.Location = new System.Drawing.Point(30, 30);
            this.btnSubirFactura.Name = "btnSubirFactura";
            this.btnSubirFactura.Size = new System.Drawing.Size(120, 30);
            this.btnSubirFactura.Text = "Subir Factura";
            this.btnSubirFactura.UseVisualStyleBackColor = true;
            this.btnSubirFactura.Click += new System.EventHandler(this.btnSubirFactura_Click);

            // 
            // txtRutaFactura
            // 
            this.txtRutaFactura.Location = new System.Drawing.Point(170, 35);
            this.txtRutaFactura.Name = "txtRutaFactura";
            this.txtRutaFactura.Size = new System.Drawing.Size(400, 23);
            this.txtRutaFactura.TabIndex = 1;
            this.txtRutaFactura.ReadOnly = true;

            // 
            // tabReportes
            // 
            this.tabReportes.Location = new System.Drawing.Point(4, 24);
            this.tabReportes.Name = "tabReportes";
            this.tabReportes.Padding = new System.Windows.Forms.Padding(3);
            this.tabReportes.Size = new System.Drawing.Size(792, 572);
            this.tabReportes.TabIndex = 2;
            this.tabReportes.Text = "Reportes";
            this.tabReportes.UseVisualStyleBackColor = true;

            // 
            // tabConsejosIA
            // 
            this.tabConsejosIA.Controls.Add(this.btnObtenerConsejo);
            this.tabConsejosIA.Controls.Add(this.txtConsejoIA);
            this.tabConsejosIA.Location = new System.Drawing.Point(4, 24);
            this.tabConsejosIA.Name = "tabConsejosIA";
            this.tabConsejosIA.Padding = new System.Windows.Forms.Padding(3);
            this.tabConsejosIA.Size = new System.Drawing.Size(792, 572);
            this.tabConsejosIA.TabIndex = 3;
            this.tabConsejosIA.Text = "Consejos IA";
            this.tabConsejosIA.UseVisualStyleBackColor = true;

            // 
            // btnObtenerConsejo
            // 
            this.btnObtenerConsejo.Location = new System.Drawing.Point(30, 30);
            this.btnObtenerConsejo.Name = "btnObtenerConsejo";
            this.btnObtenerConsejo.Size = new System.Drawing.Size(180, 30);
            this.btnObtenerConsejo.Text = "Obtener Consejo IA";
            this.btnObtenerConsejo.UseVisualStyleBackColor = true;
            this.btnObtenerConsejo.Click += new System.EventHandler(this.btnObtenerConsejo_Click);

            // 
            // txtConsejoIA
            // 
            this.txtConsejoIA.Location = new System.Drawing.Point(30, 80);
            this.txtConsejoIA.Name = "txtConsejoIA";
            this.txtConsejoIA.Size = new System.Drawing.Size(700, 400);
            this.txtConsejoIA.Multiline = true;
            this.txtConsejoIA.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtConsejoIA.ReadOnly = true;

            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.tabControl);
            this.Name = "Form1";
            this.Text = "Mi IA Financiero";
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.tabIngresosEgresos.ResumeLayout(false);
            this.tabIngresosEgresos.PerformLayout();
            this.tabFacturas.ResumeLayout(false);
            this.tabFacturas.PerformLayout();
            this.tabConsejosIA.ResumeLayout(false);
            this.tabConsejosIA.PerformLayout();
            this.ResumeLayout(false);
        }
    }
}